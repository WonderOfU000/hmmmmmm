"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, Github, Linkedin } from "lucide-react"
import ThemeToggle from "@/components/theme-toggle"
import { motion, AnimatePresence } from "framer-motion"

export default function MobileNav() {
  const [open, setOpen] = useState(false)

  return (
    <div className="md:hidden">
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="right" className="flex flex-col">
          <div className="flex items-center justify-between">
            <span className="text-lg font-bold">John Doe</span>
            <ThemeToggle />
          </div>
          <nav className="flex flex-col gap-4 mt-8">
            <AnimatePresence>
              {open && (
                <>
                  <motion.a
                    href="#about"
                    className="text-lg font-medium transition-colors hover:text-primary"
                    onClick={() => setOpen(false)}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.2, delay: 0.1 }}
                  >
                    About
                  </motion.a>
                  <motion.a
                    href="#skills"
                    className="text-lg font-medium transition-colors hover:text-primary"
                    onClick={() => setOpen(false)}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.2, delay: 0.2 }}
                  >
                    Skills
                  </motion.a>
                  <motion.a
                    href="#projects"
                    className="text-lg font-medium transition-colors hover:text-primary"
                    onClick={() => setOpen(false)}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.2, delay: 0.3 }}
                  >
                    Projects
                  </motion.a>
                  <motion.a
                    href="#contact"
                    className="text-lg font-medium transition-colors hover:text-primary"
                    onClick={() => setOpen(false)}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.2, delay: 0.4 }}
                  >
                    Contact
                  </motion.a>
                </>
              )}
            </AnimatePresence>
          </nav>
          <div className="flex gap-2 mt-8">
            <Button variant="outline" size="icon" asChild className="transition-transform duration-300 hover:scale-110">
              <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                <Github className="h-4 w-4" />
                <span className="sr-only">GitHub</span>
              </a>
            </Button>
            <Button variant="outline" size="icon" asChild className="transition-transform duration-300 hover:scale-110">
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
                <Linkedin className="h-4 w-4" />
                <span className="sr-only">LinkedIn</span>
              </a>
            </Button>
          </div>
          <div className="mt-auto text-center text-sm text-muted-foreground">© {new Date().getFullYear()} John Doe</div>
        </SheetContent>
      </Sheet>
    </div>
  )
}

