import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Github, Mail, Linkedin, ArrowRight, ExternalLink } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import MobileNav from "@/components/mobile-nav"
import ProjectCard from "@/components/project-card"
import SkillBadge from "@/components/skill-badge"
import ContactForm from "@/components/contact-form"
import ThemeToggle from "@/components/theme-toggle"
import FadeIn from "@/components/animations/fade-in"
import StaggerChildren, { StaggerItem } from "@/components/animations/stagger-children"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold">John Doe</span>
          </div>

          <div className="hidden md:flex items-center gap-6">
            <nav className="flex items-center gap-6">
              <a href="#about" className="text-sm font-medium transition-colors hover:text-primary">
                About
              </a>
              <a href="#skills" className="text-sm font-medium transition-colors hover:text-primary">
                Skills
              </a>
              <a href="#projects" className="text-sm font-medium transition-colors hover:text-primary">
                Projects
              </a>
              <a href="#contact" className="text-sm font-medium transition-colors hover:text-primary">
                Contact
              </a>
            </nav>
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <Button variant="outline" size="icon" asChild>
                <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                  <Github className="h-4 w-4" />
                  <span className="sr-only">GitHub</span>
                </a>
              </Button>
              <Button variant="outline" size="icon" asChild>
                <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
                  <Linkedin className="h-4 w-4" />
                  <span className="sr-only">LinkedIn</span>
                </a>
              </Button>
            </div>
          </div>

          <MobileNav />
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="container py-24 md:py-32 space-y-8">
          <div className="flex flex-col md:flex-row gap-8 md:gap-16 items-center">
            <FadeIn direction="right" className="flex-1 space-y-4">
              <Badge className="px-3 py-1 text-sm" variant="secondary">
                Full-Stack Developer
              </Badge>
              <h1 className="text-4xl md:text-6xl font-bold tracking-tight">Hi, I'm John Doe</h1>
              <p className="text-xl text-muted-foreground">
                I build exceptional digital experiences that make people's lives simpler through clean and functional
                design.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 pt-4">
                <Button asChild className="group">
                  <a href="#contact">
                    Get in touch{" "}
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                  </a>
                </Button>
                <Button variant="outline" asChild>
                  <a href="#projects">View my work</a>
                </Button>
              </div>
            </FadeIn>
            <FadeIn direction="left" delay={0.2} className="flex-1 flex justify-center md:justify-end">
              <div className="relative w-72 h-72 md:w-80 md:h-80 overflow-hidden rounded-full border-4 border-primary/20">
                <Image
                  src="/placeholder.svg?height=320&width=320"
                  alt="John Doe"
                  fill
                  className="object-cover"
                  priority
                />
              </div>
            </FadeIn>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="bg-muted/50 py-16 md:py-24">
          <div className="container space-y-12">
            <FadeIn className="space-y-4 text-center max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold">About Me</h2>
              <p className="text-muted-foreground">
                A passionate developer with a focus on creating beautiful, functional, and user-friendly applications.
              </p>
            </FadeIn>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <FadeIn direction="right" className="space-y-4">
                <p className="text-lg">
                  I'm a full-stack developer with over 5 years of experience building web applications. I specialize in
                  JavaScript, React, and Node.js, and I'm passionate about creating intuitive user experiences and
                  scalable backend systems.
                </p>
                <p className="text-lg">
                  When I'm not coding, you can find me hiking in the mountains, reading science fiction, or
                  experimenting with new cooking recipes. I believe in continuous learning and regularly attend tech
                  conferences and workshops.
                </p>
                <div className="pt-4">
                  <Button variant="outline" asChild className="group">
                    <a href="/resume.pdf" target="_blank" rel="noopener noreferrer">
                      Download Resume{" "}
                      <ExternalLink className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                    </a>
                  </Button>
                </div>
              </FadeIn>

              <StaggerChildren className="grid grid-cols-2 gap-4" delay={0.2} staggerDelay={0.1}>
                <StaggerItem>
                  <Card>
                    <CardContent className="p-6 flex flex-col items-center text-center">
                      <div className="text-4xl font-bold text-primary mb-2">5+</div>
                      <p className="text-muted-foreground">Years Experience</p>
                    </CardContent>
                  </Card>
                </StaggerItem>
                <StaggerItem>
                  <Card>
                    <CardContent className="p-6 flex flex-col items-center text-center">
                      <div className="text-4xl font-bold text-primary mb-2">50+</div>
                      <p className="text-muted-foreground">Projects Completed</p>
                    </CardContent>
                  </Card>
                </StaggerItem>
                <StaggerItem>
                  <Card>
                    <CardContent className="p-6 flex flex-col items-center text-center">
                      <div className="text-4xl font-bold text-primary mb-2">20+</div>
                      <p className="text-muted-foreground">Happy Clients</p>
                    </CardContent>
                  </Card>
                </StaggerItem>
                <StaggerItem>
                  <Card>
                    <CardContent className="p-6 flex flex-col items-center text-center">
                      <div className="text-4xl font-bold text-primary mb-2">10+</div>
                      <p className="text-muted-foreground">Technologies</p>
                    </CardContent>
                  </Card>
                </StaggerItem>
              </StaggerChildren>
            </div>
          </div>
        </section>

        {/* Skills Section */}
        <section id="skills" className="py-16 md:py-24">
          <div className="container space-y-12">
            <FadeIn className="space-y-4 text-center max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold">My Skills</h2>
              <p className="text-muted-foreground">
                I've worked with a variety of technologies in the web development world.
              </p>
            </FadeIn>

            <Tabs defaultValue="frontend" className="w-full">
              <div className="flex justify-center mb-8">
                <TabsList>
                  <TabsTrigger value="frontend">Frontend</TabsTrigger>
                  <TabsTrigger value="backend">Backend</TabsTrigger>
                  <TabsTrigger value="tools">Tools & Others</TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="frontend" className="space-y-4">
                <StaggerChildren className="flex flex-wrap gap-3 justify-center" staggerDelay={0.05}>
                  <StaggerItem>
                    <SkillBadge name="HTML5" level={90} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="CSS3" level={85} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="JavaScript" level={90} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="TypeScript" level={85} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="React" level={90} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="Next.js" level={85} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="Tailwind CSS" level={90} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="Redux" level={80} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="Framer Motion" level={75} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="SASS/SCSS" level={80} />
                  </StaggerItem>
                </StaggerChildren>
              </TabsContent>

              <TabsContent value="backend" className="space-y-4">
                <StaggerChildren className="flex flex-wrap gap-3 justify-center" staggerDelay={0.05}>
                  <StaggerItem>
                    <SkillBadge name="Node.js" level={85} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="Express" level={85} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="MongoDB" level={80} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="PostgreSQL" level={75} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="Firebase" level={80} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="GraphQL" level={70} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="REST API" level={90} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="Prisma" level={75} />
                  </StaggerItem>
                </StaggerChildren>
              </TabsContent>

              <TabsContent value="tools" className="space-y-4">
                <StaggerChildren className="flex flex-wrap gap-3 justify-center" staggerDelay={0.05}>
                  <StaggerItem>
                    <SkillBadge name="Git" level={90} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="GitHub" level={85} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="Docker" level={70} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="AWS" level={65} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="Vercel" level={85} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="Figma" level={75} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="Jest" level={75} />
                  </StaggerItem>
                  <StaggerItem>
                    <SkillBadge name="CI/CD" level={70} />
                  </StaggerItem>
                </StaggerChildren>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Projects Section */}
        <section id="projects" className="bg-muted/50 py-16 md:py-24">
          <div className="container space-y-12">
            <FadeIn className="space-y-4 text-center max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold">Featured Projects</h2>
              <p className="text-muted-foreground">
                Check out some of my recent work that showcases my skills and expertise.
              </p>
            </FadeIn>

            <StaggerChildren className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" staggerDelay={0.1}>
              <StaggerItem>
                <ProjectCard
                  title="E-Commerce Platform"
                  description="A full-featured online store with product management, cart functionality, and payment processing."
                  tags={["React", "Node.js", "MongoDB", "Stripe"]}
                  imageUrl="/placeholder.svg?height=300&width=500"
                  demoUrl="https://example.com"
                  repoUrl="https://github.com"
                />
              </StaggerItem>

              <StaggerItem>
                <ProjectCard
                  title="Task Management App"
                  description="A productivity application for managing tasks, projects, and team collaboration."
                  tags={["Next.js", "TypeScript", "Prisma", "PostgreSQL"]}
                  imageUrl="/placeholder.svg?height=300&width=500"
                  demoUrl="https://example.com"
                  repoUrl="https://github.com"
                />
              </StaggerItem>

              <StaggerItem>
                <ProjectCard
                  title="Real-time Chat Application"
                  description="A messaging platform with real-time updates, user authentication, and file sharing."
                  tags={["React", "Firebase", "WebSockets", "Tailwind CSS"]}
                  imageUrl="/placeholder.svg?height=300&width=500"
                  demoUrl="https://example.com"
                  repoUrl="https://github.com"
                />
              </StaggerItem>

              <StaggerItem>
                <ProjectCard
                  title="Portfolio Website"
                  description="A responsive portfolio website showcasing projects and skills with a modern design."
                  tags={["Next.js", "Tailwind CSS", "Framer Motion"]}
                  imageUrl="/placeholder.svg?height=300&width=500"
                  demoUrl="https://example.com"
                  repoUrl="https://github.com"
                />
              </StaggerItem>

              <StaggerItem>
                <ProjectCard
                  title="Weather Dashboard"
                  description="A weather application that displays current conditions and forecasts for locations worldwide."
                  tags={["JavaScript", "API Integration", "CSS3"]}
                  imageUrl="/placeholder.svg?height=300&width=500"
                  demoUrl="https://example.com"
                  repoUrl="https://github.com"
                />
              </StaggerItem>

              <StaggerItem>
                <ProjectCard
                  title="Blog Platform"
                  description="A content management system for creating, editing, and publishing blog posts."
                  tags={["React", "Node.js", "Express", "MongoDB"]}
                  imageUrl="/placeholder.svg?height=300&width=500"
                  demoUrl="https://example.com"
                  repoUrl="https://github.com"
                />
              </StaggerItem>
            </StaggerChildren>

            <FadeIn className="flex justify-center pt-8">
              <Button variant="outline" asChild className="group">
                <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                  View All Projects on GitHub{" "}
                  <Github className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:scale-110" />
                </a>
              </Button>
            </FadeIn>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-16 md:py-24">
          <div className="container space-y-12">
            <FadeIn className="space-y-4 text-center max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold">Get In Touch</h2>
              <p className="text-muted-foreground">
                Have a project in mind or want to discuss potential opportunities? Feel free to reach out!
              </p>
            </FadeIn>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
              <FadeIn direction="right" className="space-y-6">
                <h3 className="text-2xl font-semibold">Contact Information</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 group">
                    <Mail className="h-5 w-5 text-primary transition-transform duration-300 group-hover:scale-110" />
                    <a href="mailto:john.doe@example.com" className="hover:text-primary transition-colors">
                      john.doe@example.com
                    </a>
                  </div>
                  <div className="flex items-center gap-3 group">
                    <Linkedin className="h-5 w-5 text-primary transition-transform duration-300 group-hover:scale-110" />
                    <a
                      href="https://linkedin.com/in/johndoe"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary transition-colors"
                    >
                      linkedin.com/in/johndoe
                    </a>
                  </div>
                  <div className="flex items-center gap-3 group">
                    <Github className="h-5 w-5 text-primary transition-transform duration-300 group-hover:scale-110" />
                    <a
                      href="https://github.com/johndoe"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary transition-colors"
                    >
                      github.com/johndoe
                    </a>
                  </div>
                </div>

                <div className="pt-6">
                  <h3 className="text-2xl font-semibold mb-4">Let's Connect</h3>
                  <p className="text-muted-foreground mb-4">
                    I'm currently available for freelance work and full-time positions. If you have a project that needs
                    some creative touch, I'd love to hear about it!
                  </p>
                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      size="icon"
                      asChild
                      className="transition-transform duration-300 hover:scale-110"
                    >
                      <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="24"
                          height="24"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="h-4 w-4"
                        >
                          <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path>
                        </svg>
                        <span className="sr-only">Twitter</span>
                      </a>
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      asChild
                      className="transition-transform duration-300 hover:scale-110"
                    >
                      <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
                        <Linkedin className="h-4 w-4" />
                        <span className="sr-only">LinkedIn</span>
                      </a>
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      asChild
                      className="transition-transform duration-300 hover:scale-110"
                    >
                      <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                        <Github className="h-4 w-4" />
                        <span className="sr-only">GitHub</span>
                      </a>
                    </Button>
                  </div>
                </div>
              </FadeIn>

              <FadeIn direction="left" delay={0.2}>
                <ContactForm />
              </FadeIn>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t bg-muted/50">
        <div className="container py-8 md:py-12">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-xl font-bold">John Doe</span>
            </div>

            <div className="text-center md:text-right">
              <p className="text-sm text-muted-foreground">
                © {new Date().getFullYear()} John Doe. All rights reserved.
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Designed and built with ❤️ using Next.js and Tailwind CSS
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

